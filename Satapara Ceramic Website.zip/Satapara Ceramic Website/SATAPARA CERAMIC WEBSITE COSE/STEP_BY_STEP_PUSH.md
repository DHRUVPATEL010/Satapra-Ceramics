# 📋 Step-by-Step Guide: Push Your Code to GitHub

Follow these steps exactly to push your website to GitHub.

---

## STEP 1: Create a GitHub Personal Access Token

1. **Open your web browser** and go to:
   ```
   https://github.com/settings/tokens
   ```

2. **Click the button** that says:
   ```
   "Generate new token"
   ```
   Then click:
   ```
   "Generate new token (classic)"
   ```

3. **Fill in the form:**
   - **Note:** Type: `Satapara Website Push`
   - **Expiration:** Choose "90 days" or "No expiration" (your choice)
   - **Select scopes:** Scroll down and check the box next to:
     ```
     ✅ repo
     ```
     (This gives full control of private repositories)

4. **Scroll to the bottom** and click:
   ```
   "Generate token"
   ```

5. **IMPORTANT:** Copy the token immediately!
   - You'll see a long string like: `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
   - **Copy this entire token** - you won't see it again!
   - **Save it somewhere safe** (like Notes app)

---

## STEP 2: Open Terminal on Your Mac

1. **Press these keys together:**
   ```
   Command (⌘) + Space
   ```

2. **Type:** `Terminal`

3. **Press Enter** to open Terminal

---

## STEP 3: Navigate to Your Project Folder

In Terminal, type this command and press Enter:

```bash
cd "/Users/kavyapatel/Desktop/Satapara Ceramic Website/SATAPARA CERAMIC WEBSITE COSE"
```

You should see the prompt change to show you're in that folder.

---

## STEP 4: Push Your Code to GitHub

Type this command and press Enter:

```bash
git push -u origin Dev
```

---

## STEP 5: Enter Your Credentials

You'll be prompted twice:

### First Prompt: Username
```
Username for 'https://github.com':
```
**Type:** `DHRUVPATEL010`
**Press Enter**

### Second Prompt: Password
```
Password for 'https://DHRUVPATEL010@github.com':
```
**IMPORTANT:** 
- **Paste your Personal Access Token** (the one you copied in Step 1)
- **NOT your GitHub password!**
- Just paste the token and press Enter

---

## STEP 6: Wait for Upload

You'll see messages like:
```
Enumerating objects: 106, done.
Counting objects: 100% (106/106), done.
Writing objects: 100% (106/106), done.
```

This means it's working! Wait for it to finish.

---

## STEP 7: Verify Your Files Are on GitHub

1. **Open your web browser**

2. **Go to:**
   ```
   https://github.com/DHRUVPATEL010/Satapra-Ceramics
   ```

3. **Click on the branch dropdown** (it might say "main" or "master")

4. **Select "Dev"** from the dropdown

5. **You should now see all your files!**
   - index.html
   - products.html
   - css folder
   - js folder
   - images folder
   - etc.

---

## ✅ Success!

If you see all your files, you're done! 🎉

---

## ❌ If Something Goes Wrong

### Error: "Authentication failed"
- Make sure you used the **Personal Access Token**, not your GitHub password
- Make sure you copied the entire token (it's very long)

### Error: "Repository not found"
- Make sure the repository exists at: https://github.com/DHRUVPATEL010/Satapra-Ceramics
- Make sure you have access to it

### Error: "Permission denied"
- Make sure you checked the `repo` scope when creating the token
- Try creating a new token

### Still having issues?
- Check the `WHY_NO_FILES.md` file for more help
- Or try the alternative method below

---

## 🔄 Alternative: If Terminal Doesn't Work

If you prefer not to use Terminal, you can upload files directly on GitHub:

1. Go to: https://github.com/DHRUVPATEL010/Satapra-Ceramics
2. Click "Add file" → "Upload files"
3. Open the folder: `SATAPARA CERAMIC WEBSITE COSE`
4. Select ALL files (Command+A)
5. Drag and drop them into GitHub
6. Scroll down, add commit message: "Initial commit"
7. Click "Commit changes"

---

## 📞 Quick Reference

**Repository:** https://github.com/DHRUVPATEL010/Satapra-Ceramics  
**Branch:** Dev  
**Create Token:** https://github.com/settings/tokens

---

**That's it! Follow these steps and your files will be on GitHub!** 🚀

